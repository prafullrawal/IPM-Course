package com.sales.order.service.sales.order.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SalesOrderService {

	@Autowired
	ServiceOrderRepository serviceOrderRepository;
	@Autowired
	SalesOrderRepository salesOrderRepository;
	@Autowired
	FeignClientService feignClientService;
	@Autowired
	OrderLineItemRepository orderLineItemRepository;
	
	public long creatOrder(Order order) {
		
		long id = order.getCustomerid();
		
		CustomerSOS customerSOS =  serviceOrderRepository.findById(id);
		
		List<String> itemName = order.getItemNames();
		int totalPrice = 0;
		
		for (String name : itemName) {
			
			totalPrice +=  feignClientService.ItemByName(name).getPrice();
		}
		
		
		  // prepare SalesOrder
		  SalesOrder salesOrder = new SalesOrder();
		  salesOrder.setCust_id(order.getCustomerid());
		  salesOrder.setOrder_date(order.getOrderDate());
		  salesOrder.setOrder_desc(order.getOrderDescription());
		  salesOrder.setTotal_price(totalPrice);
		  
		  salesOrder =  salesOrderRepository.save(salesOrder);
		 
		  for (String itemsName : itemName) {
			//prepare order_line_item 
			  OrderLineItem orderLineItem = new OrderLineItem();
			  orderLineItem.setItem_name(itemsName);
			  orderLineItem.setOrder_id(salesOrder.getId());
			  orderLineItem.setItem_quantity(1);
			
			  orderLineItem = orderLineItemRepository.save(orderLineItem);
		  }
		  
		return salesOrder.getId();
	}
	
}
