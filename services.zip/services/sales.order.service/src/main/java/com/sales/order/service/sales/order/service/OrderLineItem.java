package com.sales.order.service.sales.order.service;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class OrderLineItem {
	
	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	@Column(name="item_name")
	private String item_name;
	@Column(name="item_quantity")
	private int item_quantity;
	@Column(name="order_id")
	private Long order_id;
	
	public OrderLineItem() {
		// TODO Auto-generated constructor stub
	}
	
	
	public OrderLineItem(long id, String item_name, int item_quantity, Long order_id) {
		super();
		this.id = id;
		this.item_name = item_name;
		this.item_quantity = item_quantity;
		this.order_id = order_id;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getItem_name() {
		return item_name;
	}
	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}
	public int getItem_quantity() {
		return item_quantity;
	}
	public void setItem_quantity(int item_quantity) {
		this.item_quantity = item_quantity;
	}
	public Long getOrder_id() {
		return order_id;
	}
	public void setOrder_id(Long order_id) {
		this.order_id = order_id;
	}


	@Override
	public String toString() {
		return "OrderLineItem [id=" + id + ", item_name=" + item_name + ", item_quantity=" + item_quantity
				+ ", order_id=" + order_id + "]";
	}

}
