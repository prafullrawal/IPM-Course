
insert into customersos (cust_id, cust_first_name, cust_last_name, cust_email) values (101,'cust1','cust1','cust1@abc.com');