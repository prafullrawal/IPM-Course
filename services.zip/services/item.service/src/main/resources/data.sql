insert into item (id,name,discription,price) values (1,'item1','success',10);
insert into item (id,name,discription,price) values (2,'item2','success',20);
insert into item (id,name,discription,price) values (3,'item3','success',30);
